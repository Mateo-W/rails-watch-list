Solution of the two-day [Watch List challenge](https://github.com/lewagon/fullstack-challenges/blob/master/05-Rails/04-Rails-mister-cocktail/02-Watch-List/README.md).

The branch `day-one` is the solution of the challenge at the end of the first day and the branch `day-two` is the complete solution of this two-day challenge.
